from __future__ import annotations

from mathproofmesh.broker_phase import record_verified_message_usage
from mathproofmesh.communication.broker import MessageBroker
from mathproofmesh.communication.receipts import build_receipt
from mathproofmesh.context_policy import select_typed_fact_context
from mathproofmesh.schemas import (
    ClaimStatus,
    EvidenceType,
    MemoryTier,
    MessageType,
    ProofDelta,
    ProofStep,
    QuantifierSpec,
    ReceiptStatus,
    VariableBinding,
)

from v07_helpers import (
    PROBLEM_HASH,
    make_broker_runtime,
    make_fact,
    make_message,
    make_v07_config,
)


def test_broker_shares_only_gated_artifacts_and_deduplicates(tmp_path) -> None:
    config = make_v07_config(tmp_path / "runs")
    _, _, _, _, broker = make_broker_runtime(config, tmp_path)

    insight = make_message(
        message_id="insight",
        route_id="route-a",
        agent_id="author-a",
        target_routes=["route-b"],
    )
    local = broker.publish(insight, referee_agent_id=None, current_round=1)
    assert local.accepted
    assert local.selected_targets == []
    assert local.rejected_targets["route-b"].startswith("cross-route")

    fact = make_fact(
        message_id="fact-a",
        target_routes=["route-b", "route-c"],
    )
    shared = broker.publish(fact, referee_agent_id="referee-a", current_round=1)
    assert shared.accepted
    assert set(shared.selected_targets) == {"route-b", "route-c"}

    duplicate = make_fact(
        message_id="fact-a-copy",
        target_routes=["route-b"],
    )
    decision = broker.publish(duplicate, referee_agent_id="referee-a", current_round=1)
    assert decision.duplicate_of == "fact-a"


def test_only_broker_admitted_facts_are_global_context(tmp_path) -> None:
    config = make_v07_config(tmp_path / "runs")
    _, _, typed_memory, _, broker = make_broker_runtime(config, tmp_path)
    direct_fact = make_fact(
        message_id="direct-typed-fact",
        statement="a directly inserted typed fact",
    )
    typed_memory.add_fact(
        direct_fact,
        referee_agent_id="independent-referee",
    )
    broker_fact = make_fact(
        message_id="broker-admitted-fact",
        statement="a broker admitted typed fact",
    )
    decision = broker.publish(
        broker_fact,
        referee_agent_id="independent-referee",
        current_round=1,
    )

    assert decision.accepted
    assert direct_fact in typed_memory.facts
    assert broker_fact in typed_memory.facts
    admitted_ids = {item.message_id for item in broker.admitted_facts()}
    assert broker_fact.message_id in admitted_ids
    assert direct_fact.message_id not in admitted_ids
    assert broker.export_state()["admitted_fact_ids"] == [broker_fact.message_id]


def test_admitted_fact_context_includes_only_complete_dependency_closures(
    tmp_path,
) -> None:
    config = make_v07_config(tmp_path / "runs")
    _, _, _, _, broker = make_broker_runtime(config, tmp_path)
    dependency = make_fact(
        message_id="fact-dependency",
        statement="the exact local difference identity",
    )
    root = make_fact(
        message_id="fact-root",
        statement="the global telescoping identity",
        dependencies=[dependency.message_id],
    )
    assert broker.publish(
        dependency,
        referee_agent_id="independent-referee",
        current_round=1,
    ).accepted
    assert broker.publish(
        root,
        referee_agent_id="independent-referee",
        current_round=1,
    ).accepted

    context = select_typed_fact_context(
        broker.admitted_facts(),
        broker=broker,
        query="global telescoping identity",
        max_chars=20000,
        max_items=4,
    )

    assert [item["message_id"] for item in context] == [
        dependency.message_id,
        root.message_id,
    ]
    serialized = str(context)
    assert "author-a" not in serialized
    assert "route-a" not in serialized


def test_broker_resume_preserves_exactly_once_prompt_delivery(tmp_path) -> None:
    config = make_v07_config(tmp_path / "runs")
    store, registry, memory, graph, broker = make_broker_runtime(config, tmp_path)
    fact = make_fact(message_id="once", target_routes=["route-b"])
    broker.publish(fact, referee_agent_id="referee-a", current_round=1)
    assert [item.message_id for item in broker.inbox("route-b", current_round=1)] == [
        "once"
    ]

    restored = MessageBroker.from_state(
        broker.export_state(),
        config=config,
        store=store,
        activity=None,
        route_registry=registry,
        proof_graph=graph,
        typed_memory=memory,
    )
    assert restored.inbox("route-b", current_round=1) == []
    delivery = next(iter(restored.export_state()["deliveries"].values()))
    assert delivery["prompt_consumed"] is True
    assert delivery["status"] == "pending"

    receipt = build_receipt(
        fact, "route-b", status=ReceiptStatus.ACCEPTED, delivered_round=1
    )
    restored.acknowledge(receipt)
    assert restored.receipts[0].status == ReceiptStatus.ACCEPTED


def test_invalidated_delivery_is_archived_without_blocking_republication(
    tmp_path,
) -> None:
    config = make_v07_config(tmp_path / "runs")
    _, _, typed_memory, graph, broker = make_broker_runtime(config, tmp_path)
    fact = make_fact(message_id="reusable", target_routes=["route-b"])
    assert broker.publish(
        fact,
        referee_agent_id="referee-a",
        current_round=1,
    ).accepted

    reason = "checkpoint_rolled_back:checkpoint-abandoned"
    invalidated = typed_memory.invalidate_dependents(
        [fact.message_id],
        reason=reason,
    )
    broker.invalidate_messages(invalidated, reason=reason)
    graph.invalidate_evidence_messages(invalidated, reason=reason)

    state = broker.export_state()
    assert state["deliveries"] == {}
    archived = next(iter(state["invalidated_deliveries"].values()))
    assert archived["delivery_state"] == "invalidated"
    assert archived["invalidation_reason"] == reason
    assert broker.inbox("route-b", current_round=1) == []

    republished = broker.publish(
        fact,
        referee_agent_id="referee-a",
        current_round=2,
    )
    assert republished.accepted
    assert republished.selected_targets == ["route-b"]
    assert broker.delivery_record(fact.message_id, "route-b") is not None
    assert [item.message_id for item in broker.inbox("route-b", current_round=2)] == [
        fact.message_id
    ]


def test_receipt_rejects_quantifier_reversal_and_binding_scope_change(tmp_path) -> None:
    config = make_v07_config(tmp_path / "runs")
    _, _, _, _, broker = make_broker_runtime(config, tmp_path)
    bindings = [
        VariableBinding(
            variable_id="n",
            display_name="n",
            domain="positive integers",
            owner_scope="claim",
        ),
        VariableBinding(
            variable_id="m",
            display_name="M",
            domain="positive integers",
            owner_scope="depends on n",
        ),
    ]
    message = make_fact(
        message_id="quantified",
        target_routes=["route-b"],
        quantifiers=[
            QuantifierSpec(
                order=0,
                kind="forall",
                variable_id="n",
                display_name="n",
                domain="positive integers",
            ),
            QuantifierSpec(
                order=1,
                kind="exists",
                variable_id="m",
                display_name="M",
                domain="positive integers",
            ),
        ],
        variable_bindings=bindings,
    )
    broker.publish(message, referee_agent_id="referee-a", current_round=1)
    broker.inbox("route-b", current_round=1)
    reversed_quantifiers = [
        item.model_copy(update={"order": 1 - item.order})
        for item in message.quantifiers
    ]
    from mathproofmesh.communication.receipts import build_receipt

    receipt = build_receipt(
        message,
        "route-b",
        delivered_round=1,
        parsed_quantifiers=sorted(reversed_quantifiers, key=lambda item: item.order),
        parsed_variable_bindings=bindings,
    )
    broker.acknowledge(receipt)
    assert receipt.status == ReceiptStatus.REJECTED
    assert receipt.reason == "semantic hash mismatch"


def test_message_utility_requires_verified_mathematical_use(tmp_path) -> None:
    config = make_v07_config(tmp_path / "runs")
    _, _, _, _, broker = make_broker_runtime(config, tmp_path)
    message = make_fact(message_id="useful", target_routes=["route-b"])
    broker.publish(message, referee_agent_id="referee-a", current_round=1)
    broker.inbox("route-b", current_round=1)
    broker.acknowledge(build_receipt(message, "route-b", delivered_round=1))
    assert broker.utility_for_route("route-b") == 0.0
    assert not broker.record_utility("useful", "route-b")
    assert not broker.record_utility(
        "useful",
        "route-b",
        proof_debt_before=2.0,
        proof_debt_after=1.0,
    )
    assert broker.record_utility("useful", "route-b", referenced_step_ids=["step-2"])
    assert broker.utility_for_route("route-b") > 0.0


def test_counterexample_dependencies_propagate_to_every_affected_route(
    tmp_path,
) -> None:
    config = make_v07_config(tmp_path / "runs")
    _, _, typed_memory, _, broker = make_broker_runtime(config, tmp_path)
    fact = make_fact(
        message_id="shared-premise",
        statement="Every generated term is congruent to one modulo four.",
        target_routes=["route-b"],
    )
    broker.publish(fact, referee_agent_id="referee-a", current_round=1)
    counterexample = make_message(
        message_id="premise-counterexample",
        route_id="route-c",
        agent_id="author-c",
        statement="The generated term at index five is three modulo four.",
        conclusion=fact.normalized_statement,
        dependencies=[fact.message_id],
        message_type=MessageType.COUNTEREXAMPLE,
        evidence_type=EvidenceType.COUNTEREXAMPLE,
        memory_tier=MemoryTier.NEGATIVE,
        status=ClaimStatus.REJECTED,
        confidence=0.95,
        normalization_confidence=0.95,
    )

    decision = broker.publish(
        counterexample,
        referee_agent_id="referee-c",
        current_round=1,
    )

    assert decision.accepted
    assert set(decision.selected_targets) == {"route-a", "route-b"}
    assert fact.message_id not in {item.message_id for item in typed_memory.facts}
    assert fact.message_id in {
        item.message_id
        for item in typed_memory.negatives
        if hasattr(item, "message_id")
    }


def test_broker_phase_credits_only_a_verified_delta_reference(tmp_path) -> None:
    config = make_v07_config(tmp_path / "runs")
    _, _, _, graph, broker = make_broker_runtime(config, tmp_path)
    message = make_fact(message_id="cited", target_routes=["route-b"])
    broker.publish(message, referee_agent_id="referee-a", current_round=1)
    broker.inbox("route-b", current_round=1)
    receipt = build_receipt(
        message,
        "route-b",
        delivered_round=1,
        referenced_in_step_ids=["actual-step", "invented-step"],
    )
    broker.acknowledge(receipt)
    delta = ProofDelta(
        problem_hash=PROBLEM_HASH,
        path_id="path-b",
        strategy_id="strategy-1",
        parent_checkpoint_id="checkpoint-b",
        agent_id="author-b",
        round_index=1,
        segment_index=1,
        new_steps=[
            ProofStep(
                step_id="actual-step",
                statement="Apply the independently audited identity.",
                justification="The cited cross-route result supplies this equality.",
                dependencies=[message.message_id],
            )
        ],
        remaining_subgoals=["Finish the route."],
    )

    used = record_verified_message_usage(
        broker,
        [message],
        [receipt],
        delta,
        route_id="route-b",
        proof_graph=graph,
        proof_debt_before=2.0,
    )

    assert used == [message.message_id]
    state = broker.export_state()
    utility = next(iter(state["utility_records"].values()))
    assert utility["referenced_step_ids"] == ["actual-step"]
    assert "invented-step" not in utility["referenced_step_ids"]
