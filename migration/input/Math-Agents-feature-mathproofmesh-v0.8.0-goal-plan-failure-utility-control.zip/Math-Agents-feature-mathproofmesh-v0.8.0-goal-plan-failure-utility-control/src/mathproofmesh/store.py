from __future__ import annotations

import json
import os
import re
import tempfile
import threading
import time
from pathlib import Path
from typing import Any

from pydantic import BaseModel

from .schemas import (
    CheckpointStatus,
    EvidenceRef,
    ProofCheckpoint,
    WorkingProofCheckpoint,
    stable_hash,
    utc_now_iso,
)


def _safe_name(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9_.-]+", "_", value.strip())
    return value[:160] or "artifact"


def _to_jsonable(value: Any) -> Any:
    if isinstance(value, BaseModel):
        return _to_jsonable(value.model_dump(mode="json"))
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(key): _to_jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_to_jsonable(item) for item in value]
    return value


class ArtifactStore:
    """Run-scoped, append-friendly artifact storage with content hashes and atomic writes."""

    def __init__(self, run_root: str | Path, run_id: str) -> None:
        self._write_lock = threading.RLock()
        self.run_id = _safe_name(run_id)
        self.root = Path(run_root).expanduser().resolve() / self.run_id
        for subdir in [
            "raw",
            "structured",
            "reports",
            "checkpoints",
            "tools",
            "prompts",
            "deltas",
            "experiments",
            "communication",
            "proof_graph",
            "inspiration",
            "verification",
            "events",
        ]:
            (self.root / subdir).mkdir(parents=True, exist_ok=True)
        self.events_path = self.root / "events.jsonl"

    @staticmethod
    def _replace_with_retry(source: str, destination: Path) -> None:
        """Tolerate brief Windows sharing locks without weakening atomic replacement."""

        attempts = 9
        for attempt in range(attempts):
            try:
                os.replace(source, destination)
                return
            except PermissionError:
                if attempt == attempts - 1:
                    raise
                time.sleep(min(0.02 * (2**attempt), 0.5))

    def _atomic_write(self, path: Path, content: str) -> None:
        with self._write_lock:
            path.parent.mkdir(parents=True, exist_ok=True)
            fd, tmp_name = tempfile.mkstemp(
                prefix=f".{path.name}.", dir=str(path.parent)
            )
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    f.write(content)
                    f.flush()
                    os.fsync(f.fileno())
                self._replace_with_retry(tmp_name, path)
            finally:
                if os.path.exists(tmp_name):
                    try:
                        os.unlink(tmp_name)
                    except OSError:
                        # Never hide the original replacement failure with a
                        # secondary best-effort temporary-file cleanup error.
                        pass

    def write_json(self, subdir: str, name: str, value: Any) -> str:
        path = self.root / _safe_name(subdir) / f"{_safe_name(name)}.json"
        content = json.dumps(
            _to_jsonable(value), ensure_ascii=False, indent=2, sort_keys=True
        )
        self._atomic_write(path, content)
        return self.ref(path)

    def write_text(
        self, subdir: str, name: str, content: str, suffix: str = ".txt"
    ) -> str:
        suffix = suffix if suffix.startswith(".") else f".{suffix}"
        path = self.root / _safe_name(subdir) / f"{_safe_name(name)}{suffix}"
        self._atomic_write(path, content)
        return self.ref(path)

    def write_content_addressed(
        self,
        subdir: str,
        content: str | dict[str, Any] | list[Any],
        *,
        suffix: str = ".json",
        summary: str = "",
        section: str | None = None,
    ) -> EvidenceRef:
        if isinstance(content, str):
            serialized = content
        else:
            serialized = json.dumps(
                content, ensure_ascii=False, indent=2, sort_keys=True
            )
        digest = stable_hash(serialized)
        suffix = suffix if suffix.startswith(".") else f".{suffix}"
        path = self.root / _safe_name(subdir) / f"{digest}{suffix}"
        if not path.exists():
            self._atomic_write(path, serialized)
        return EvidenceRef(
            artifact_ref=self.ref(path),
            section=section,
            content_hash=digest,
            summary=summary,
        )

    def append_event(self, event_type: str, payload: Any) -> None:
        event = {
            "timestamp": utc_now_iso(),
            "run_id": self.run_id,
            "event_type": event_type,
            "payload": _to_jsonable(payload),
        }
        with self.events_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n")

    def append_message_event(self, event_type: str, payload: Any) -> None:
        """Persist the message protocol stream without removing the legacy log."""
        event = {
            "timestamp": utc_now_iso(),
            "run_id": self.run_id,
            "event_type": event_type,
            "payload": _to_jsonable(payload),
        }
        path = self.root / "events" / "messages.jsonl"
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n")

    def checkpoint(self, stage: str, state: Any) -> str:
        return self.write_json("checkpoints", f"{stage}_latest", state)

    def commit_proof_checkpoint(self, checkpoint: ProofCheckpoint) -> str:
        """Persist one verified checkpoint and atomically advance the path pointer.

        The latest pointer is monotone: a new checkpoint must extend the current
        checkpoint for the same immutable problem/path/strategy by exactly one segment.
        Recommitting the same checkpoint is idempotent.
        """
        if checkpoint.status not in {
            CheckpointStatus.VERIFIED,
            CheckpointStatus.COMMITTED,
        }:
            raise ValueError(
                "only verified or committed proof checkpoints may become resume points"
            )
        path_dir = self.root / "checkpoints" / "proof" / _safe_name(checkpoint.path_id)
        path_dir.mkdir(parents=True, exist_ok=True)
        latest_path = path_dir / "latest.json"
        checkpoint_path = (
            path_dir
            / f"{checkpoint.segment_index:04d}_{_safe_name(checkpoint.checkpoint_id)}.json"
        )

        if latest_path.exists():
            with latest_path.open("r", encoding="utf-8") as handle:
                latest = ProofCheckpoint.model_validate(json.load(handle))
            if latest.checkpoint_id == checkpoint.checkpoint_id:
                return self.ref(checkpoint_path)
            if checkpoint.parent_checkpoint_id != latest.checkpoint_id:
                raise ValueError(
                    "proof checkpoint does not extend the current latest checkpoint"
                )
            if checkpoint.segment_index != latest.segment_index + 1:
                raise ValueError(
                    "proof checkpoint segment index must advance exactly by one"
                )
            if (
                checkpoint.problem_hash != latest.problem_hash
                or checkpoint.strategy_id != latest.strategy_id
                or checkpoint.path_id != latest.path_id
            ):
                raise ValueError("proof checkpoint changed immutable path identity")
        elif (
            checkpoint.segment_index != 0 or checkpoint.parent_checkpoint_id is not None
        ):
            raise ValueError(
                "the first proof checkpoint for a path must be a genesis checkpoint"
            )

        content = json.dumps(
            _to_jsonable(checkpoint), ensure_ascii=False, indent=2, sort_keys=True
        )
        self._atomic_write(checkpoint_path, content)
        self._atomic_write(latest_path, content)
        self.append_event(
            "proof_checkpoint_committed",
            {
                "checkpoint_id": checkpoint.checkpoint_id,
                "parent_checkpoint_id": checkpoint.parent_checkpoint_id,
                "path_id": checkpoint.path_id,
                "strategy_id": checkpoint.strategy_id,
                "segment_index": checkpoint.segment_index,
                "source_agent_id": checkpoint.source_agent_id,
                "proof_complete": checkpoint.proof_complete,
                "content_hash": checkpoint.content_hash,
            },
        )
        return self.ref(checkpoint_path)

    def load_latest_proof_checkpoint(self, path_id: str) -> ProofCheckpoint | None:
        latest_path = (
            self.root / "checkpoints" / "proof" / _safe_name(path_id) / "latest.json"
        )
        if not latest_path.exists():
            return None
        with latest_path.open("r", encoding="utf-8") as f:
            return ProofCheckpoint.model_validate(json.load(f))

    def load_proof_checkpoint(
        self,
        path_id: str,
        checkpoint_id: str,
    ) -> ProofCheckpoint | None:
        """Load one immutable checkpoint from a path's retained history."""

        path_dir = self.root / "checkpoints" / "proof" / _safe_name(path_id)
        if not path_dir.exists():
            return None
        for candidate_path in sorted(path_dir.glob("[0-9][0-9][0-9][0-9]_*.json")):
            try:
                with candidate_path.open("r", encoding="utf-8") as handle:
                    candidate = ProofCheckpoint.model_validate(json.load(handle))
            except (OSError, ValueError, json.JSONDecodeError):
                continue
            if candidate.checkpoint_id == checkpoint_id:
                return candidate
        return None

    def activate_proof_checkpoint(
        self,
        path_id: str,
        checkpoint_id: str,
        *,
        reason: str,
    ) -> ProofCheckpoint:
        """Atomically select any retained verified checkpoint as resume head."""

        checkpoint = self.load_proof_checkpoint(path_id, checkpoint_id)
        if checkpoint is None:
            raise KeyError(
                f"unknown proof checkpoint {checkpoint_id!r} on path {path_id!r}"
            )
        if checkpoint.status not in {
            CheckpointStatus.VERIFIED,
            CheckpointStatus.COMMITTED,
        }:
            raise ValueError("only verified checkpoints may become resume heads")
        path_dir = self.root / "checkpoints" / "proof" / _safe_name(path_id)
        latest_path = path_dir / "latest.json"
        previous = self.load_latest_proof_checkpoint(path_id)
        if previous is not None and previous.checkpoint_id == checkpoint.checkpoint_id:
            return checkpoint
        content = json.dumps(
            _to_jsonable(checkpoint), ensure_ascii=False, indent=2, sort_keys=True
        )
        self._atomic_write(latest_path, content)
        self.append_event(
            "proof_checkpoint_activated",
            {
                "path_id": path_id,
                "from_checkpoint_id": (
                    previous.checkpoint_id if previous is not None else None
                ),
                "to_checkpoint_id": checkpoint.checkpoint_id,
                "reason": reason,
            },
        )
        return checkpoint

    def list_proof_checkpoint_frontier(
        self,
        path_id: str,
    ) -> list[ProofCheckpoint]:
        """Return retained leaf checkpoints for deterministic branch search."""

        retained = self.list_proof_checkpoints(path_id, include_abandoned=True)
        parent_ids = {
            item.parent_checkpoint_id
            for item in retained
            if item.parent_checkpoint_id is not None
        }
        return [item for item in retained if item.checkpoint_id not in parent_ids]

    def select_best_proof_checkpoint(
        self,
        path_id: str,
    ) -> ProofCheckpoint | None:
        """Choose the strongest retained leaf without changing active state."""

        frontier = self.list_proof_checkpoint_frontier(path_id)
        if not frontier:
            return None
        return max(
            frontier,
            key=lambda item: (
                item.proof_complete,
                -len(item.remaining_subgoals),
                len(item.verified_steps),
                len(item.verified_claim_ids),
                -len(item.known_risks),
                item.segment_index,
                item.created_at,
                item.checkpoint_id,
            ),
        )

    def rollback_proof_checkpoint(
        self,
        path_id: str,
        *,
        reason: str,
    ) -> ProofCheckpoint | None:
        """Move the path's resume pointer back to the parent checkpoint.

        Proof search is tree search: when a committed step turns out to be
        wrong, the correct prefix must stay reusable instead of the whole
        path being abandoned. The abandoned descendant stays on disk as
        history; the next committed delta from the restored parent starts a
        new branch (same path, different checkpoint ID at that segment).
        """
        path_dir = self.root / "checkpoints" / "proof" / _safe_name(path_id)
        latest_path = path_dir / "latest.json"
        if not latest_path.exists():
            return None
        with latest_path.open("r", encoding="utf-8") as handle:
            latest = ProofCheckpoint.model_validate(json.load(handle))
        if latest.parent_checkpoint_id is None:
            return None
        parent = self.load_proof_checkpoint(path_id, latest.parent_checkpoint_id)
        if parent is None:
            return None
        content = json.dumps(
            _to_jsonable(parent), ensure_ascii=False, indent=2, sort_keys=True
        )
        self._atomic_write(latest_path, content)
        self.append_event(
            "proof_checkpoint_rolled_back",
            {
                "path_id": path_id,
                "from_checkpoint_id": latest.checkpoint_id,
                "to_checkpoint_id": parent.checkpoint_id,
                "from_segment_index": latest.segment_index,
                "to_segment_index": parent.segment_index,
                "reason": reason,
            },
        )
        return parent

    def save_working_checkpoint(self, checkpoint: WorkingProofCheckpoint) -> str:
        """Persist route-local work without advancing the verified resume pointer."""

        path_dir = (
            self.root / "checkpoints" / "working" / _safe_name(checkpoint.path_id)
        )
        path_dir.mkdir(parents=True, exist_ok=True)
        checkpoint_path = path_dir / (
            f"{checkpoint.segment_index:04d}_"
            f"{_safe_name(checkpoint.working_checkpoint_id)}.json"
        )
        content = json.dumps(
            _to_jsonable(checkpoint), ensure_ascii=False, indent=2, sort_keys=True
        )
        self._atomic_write(checkpoint_path, content)
        self._atomic_write(path_dir / "latest.json", content)
        self.append_event(
            "working_checkpoint_saved",
            {
                "working_checkpoint_id": checkpoint.working_checkpoint_id,
                "parent_verified_checkpoint_id": (
                    checkpoint.parent_verified_checkpoint_id
                ),
                "path_id": checkpoint.path_id,
                "segment_index": checkpoint.segment_index,
                "status": checkpoint.status,
            },
        )
        return self.ref(checkpoint_path)

    def load_latest_working_checkpoint(
        self, path_id: str
    ) -> WorkingProofCheckpoint | None:
        path = (
            self.root / "checkpoints" / "working" / _safe_name(path_id) / "latest.json"
        )
        if not path.exists():
            return None
        with path.open("r", encoding="utf-8") as handle:
            return WorkingProofCheckpoint.model_validate(json.load(handle))

    def list_working_checkpoints(
        self, path_id: str | None = None
    ) -> list[WorkingProofCheckpoint]:
        root = self.root / "checkpoints" / "working"
        if not root.exists():
            return []
        roots = (
            [root / _safe_name(path_id)]
            if path_id
            else [item for item in root.iterdir() if item.is_dir()]
        )
        result: list[WorkingProofCheckpoint] = []
        for item in roots:
            for path in sorted(item.glob("[0-9][0-9][0-9][0-9]_*.json")):
                try:
                    with path.open("r", encoding="utf-8") as handle:
                        result.append(
                            WorkingProofCheckpoint.model_validate(json.load(handle))
                        )
                except (OSError, ValueError, json.JSONDecodeError):
                    continue
        return sorted(
            result,
            key=lambda checkpoint: (
                checkpoint.path_id,
                checkpoint.segment_index,
                checkpoint.created_at,
            ),
        )

    def list_proof_checkpoints(
        self,
        path_id: str | None = None,
        *,
        include_abandoned: bool = False,
    ) -> list[ProofCheckpoint]:
        """List active checkpoint lineages, or retained branch history on request.

        Rollback preserves immutable descendant files for audit, but normal
        consumers must see only the lineage reachable from each path's current
        ``latest.json`` pointer. Otherwise an abandoned descendant can regain
        authority during resume or final synthesis.
        """

        proof_root = self.root / "checkpoints" / "proof"
        if not proof_root.exists():
            return []
        roots = (
            [proof_root / _safe_name(path_id)]
            if path_id
            else [p for p in proof_root.iterdir() if p.is_dir()]
        )
        checkpoints: list[ProofCheckpoint] = []
        for root in roots:
            if not root.exists():
                continue
            path_checkpoints: list[ProofCheckpoint] = []
            for path in sorted(root.glob("[0-9][0-9][0-9][0-9]_*.json")):
                try:
                    with path.open("r", encoding="utf-8") as f:
                        path_checkpoints.append(
                            ProofCheckpoint.model_validate(json.load(f))
                        )
                except (OSError, ValueError, json.JSONDecodeError):
                    continue
            if include_abandoned:
                checkpoints.extend(path_checkpoints)
                continue
            latest_path = root / "latest.json"
            if not latest_path.exists():
                # Legacy runs may predate the latest-pointer file.
                checkpoints.extend(path_checkpoints)
                continue
            try:
                with latest_path.open("r", encoding="utf-8") as handle:
                    latest = ProofCheckpoint.model_validate(json.load(handle))
            except (OSError, ValueError, json.JSONDecodeError):
                checkpoints.extend(path_checkpoints)
                continue
            by_id = {item.checkpoint_id: item for item in path_checkpoints}
            by_id.setdefault(latest.checkpoint_id, latest)
            active_ids: set[str] = set()
            cursor: ProofCheckpoint | None = latest
            while cursor is not None and cursor.checkpoint_id not in active_ids:
                active_ids.add(cursor.checkpoint_id)
                cursor = (
                    by_id.get(cursor.parent_checkpoint_id)
                    if cursor.parent_checkpoint_id is not None
                    else None
                )
            checkpoints.extend(
                item for item in path_checkpoints if item.checkpoint_id in active_ids
            )
        return sorted(
            checkpoints,
            key=lambda item: (item.path_id, item.segment_index, item.created_at),
        )

    def save_proof_delta(
        self, delta_id: str, value: Any, *, rejected: bool = False
    ) -> str:
        suffix = "rejected" if rejected else "candidate"
        return self.write_json("deltas", f"{suffix}_{delta_id}", value)

    def write_experiment_artifact(
        self,
        request_hash: str,
        name: str,
        value: Any,
        *,
        text: bool = False,
    ) -> str:
        """Write one canonical file under experiments/<request_hash>/ atomically."""
        experiment_dir = self.root / "experiments" / _safe_name(request_hash)
        experiment_dir.mkdir(parents=True, exist_ok=True)
        filename = _safe_name(name)
        if text:
            path = experiment_dir / filename
            content = str(value)
        else:
            path = experiment_dir / (
                filename if filename.endswith(".json") else f"{filename}.json"
            )
            content = json.dumps(
                _to_jsonable(value), ensure_ascii=False, indent=2, sort_keys=True
            )
        self._atomic_write(path, content)
        return self.ref(path)

    def read_experiment_artifact(self, request_hash: str, name: str) -> Any:
        experiment_dir = self.root / "experiments" / _safe_name(request_hash)
        filename = _safe_name(name)
        path = experiment_dir / (
            filename if filename.endswith(".json") else f"{filename}.json"
        )
        with path.open("r", encoding="utf-8") as handle:
            return json.load(handle)

    def read_experiment_text_artifact(self, request_hash: str, name: str) -> str:
        experiment_dir = self.root / "experiments" / _safe_name(request_hash)
        path = experiment_dir / _safe_name(name)
        return path.read_text(encoding="utf-8")

    def has_experiment_artifact(self, request_hash: str, name: str) -> bool:
        experiment_dir = self.root / "experiments" / _safe_name(request_hash)
        filename = _safe_name(name)
        path = experiment_dir / (
            filename if filename.endswith(".json") else f"{filename}.json"
        )
        return path.exists()

    def list_experiment_results(self) -> list[dict[str, Any]]:
        results: list[dict[str, Any]] = []
        root = self.root / "experiments"
        if not root.exists():
            return results
        for path in sorted(root.glob("*/result.json")):
            try:
                with path.open("r", encoding="utf-8") as handle:
                    payload = json.load(handle)
                if isinstance(payload, dict):
                    results.append(payload)
            except (OSError, ValueError, json.JSONDecodeError):
                continue
        return results

    def latest_stage_checkpoint(self) -> tuple[str, dict[str, Any]] | None:
        candidates = [
            path
            for path in (self.root / "checkpoints").glob("*_latest.json")
            if path.is_file()
        ]
        if not candidates:
            return None
        latest = max(candidates, key=lambda path: path.stat().st_mtime_ns)
        with latest.open("r", encoding="utf-8") as f:
            payload = json.load(f)
        stage = latest.name.removesuffix("_latest.json")
        if not isinstance(payload, dict):
            raise ValueError(f"stage checkpoint {latest} must contain a JSON object")
        return stage, payload

    def read_named_json(self, subdir: str, name: str) -> Any:
        path = self.root / _safe_name(subdir) / f"{_safe_name(name)}.json"
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)

    def has_named_json(self, subdir: str, name: str) -> bool:
        return (self.root / _safe_name(subdir) / f"{_safe_name(name)}.json").exists()

    def save_prompt(self, stage: str, agent_id: str, system: str, user: str) -> str:
        """Persist an immutable prompt artifact instead of overwriting repeated stages."""
        content = f"# SYSTEM\n{system}\n\n# USER\n{user}\n"
        evidence = self.write_content_addressed(
            "prompts",
            content,
            suffix=".txt",
            summary=f"Prompt for {stage} sent to {agent_id}",
        )
        return evidence.artifact_ref

    def ref(self, path: str | Path) -> str:
        path = Path(path).resolve()
        relative = path.relative_to(self.root)
        return f"artifact://{relative.as_posix()}"

    def resolve(self, ref: str) -> Path:
        if not ref.startswith("artifact://"):
            raise ValueError(f"not an artifact ref: {ref}")
        relative = ref.removeprefix("artifact://")
        path = (self.root / relative).resolve()
        path.relative_to(self.root)  # path traversal guard
        return path

    def read_json(self, ref: str) -> Any:
        with self.resolve(ref).open("r", encoding="utf-8") as f:
            return json.load(f)
